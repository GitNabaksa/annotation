package javax.annotation.sql;

import java.lang.annotation.Annotation;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({java.lang.annotation.ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Repeatable(DataSourceDefinitions.class)
public @interface DataSourceDefinition
{
  public abstract String name();

  public abstract String className();

  public abstract String description();

  public abstract String url();

  public abstract String user();

  public abstract String password();

  public abstract String databaseName();

  public abstract int portNumber();

  public abstract String serverName();

  public abstract int isolationLevel();

  public abstract boolean transactional();

  public abstract int initialPoolSize();

  public abstract int maxPoolSize();

  public abstract int minPoolSize();

  public abstract int maxIdleTime();

  public abstract int maxStatements();

  public abstract String[] properties();

  public abstract int loginTimeout();
}