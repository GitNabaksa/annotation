package javax.annotation;

import java.lang.annotation.Annotation;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({java.lang.annotation.ElementType.TYPE, java.lang.annotation.ElementType.FIELD, java.lang.annotation.ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Repeatable(Resources.class)
public @interface Resource
{
  public abstract String name();

  public abstract String lookup();

  public abstract Class<?> type();

  public abstract Resource.AuthenticationType authenticationType();

  public abstract boolean shareable();

  public abstract String mappedName();

  public abstract String description();
  
  public enum AuthenticationType {
    CONTAINER, 
    APPLICATION;
  }
  
}